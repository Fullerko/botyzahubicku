Úprava patičky BotyZaHubicku.cz

Nahraj / přepiš tyto 2 soubory ve svém projektu:

1) app/templates/base.html
2) app/static/css/style.css

Co je přidáno:
- telefon +420 728 710 852
- WhatsApp proklik: https://wa.me/420728710852
- Instagram proklik: https://www.instagram.com/botyzahubicku.cz/
- Facebook proklik: https://www.facebook.com/botyzahubicku.cz
- TikTok proklik: https://www.tiktok.com/@botyzahubicku.cz
- nové elegantní tlačítkové ikony v patičce

Po nahrání restartuj Flask/aplikaci a obnov stránku tvrdým refreshem Ctrl+F5.
